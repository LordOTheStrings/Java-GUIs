import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class BehGen {

    JPanel title, titleimagePanel, creditstextPanel, creditsimagePanel;
    JLabel titleimageLabel, titlelab, creditsimageLabel;
    JTextArea creditstextarea1, creditstextarea2;
    Container cont;

    Font tfont = new Font("Times New Roman", Font.BOLD, 44);

    Font tbfont = new Font("Times New Roman", Font.PLAIN, 36);

    Font credfont = new Font("Times New Roman", Font.PLAIN, 24);

    Font credfont2 = new Font("Times New Roman", Font.ITALIC, 18);

    ImageIcon titleimage, creditsimage;

    JButton start;
    JButton credits;

    CreditsHandler creditsHandler = new CreditsHandler();


    public static void main(String[] args) {
        new BehGen();
    }

    public BehGen() {

        JFrame f = new JFrame("D&D 5E Beholder Generator");

        f.setSize(750, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.BLACK);

        f.setLayout(null);

        f.setResizable(false);

        f.setVisible(true);

        cont = f.getContentPane();

        title = new JPanel();
        title.setBounds(50, 50, 630, 200);
        title.setBackground(Color.BLACK);
        cont.add(title);
        titlelab = new JLabel("BEHOLDER GENERATOR (5e)");
        titlelab.setForeground(Color.RED);
        titlelab.setFont(tfont);
        title.add(titlelab);

        start = new JButton("Start");
        start.setBounds(300, 275, 125, 75);
        start.setBackground(Color.RED);
        start.setForeground(Color.WHITE);
        start.setFont(tbfont);

        credits = new JButton("Credits");
        credits.setBounds(300, 350, 125, 75);
        credits.setBackground(Color.RED);
        credits.setForeground(Color.WHITE);
        credits.setFont(credfont);
        credits.addActionListener(creditsHandler);

        cont.add(start);
        cont.add(credits);

        titleimage = new ImageIcon("C:\\Users\\cmorl\\IdeaProjects\\BeholderGen\\res\\EyeOfBeholder.png");

        titleimagePanel = new JPanel();

        titleimagePanel.setBounds(275, 100, 175, 175);
        titleimagePanel.setBackground(Color.BLACK);
        cont.add(titleimagePanel);

        titleimageLabel = new JLabel();

        titleimagePanel.add(titleimageLabel);
        titleimageLabel.setIcon(titleimage);
    }

    public void creditsScreen() {

        titleimagePanel.setVisible(false);
        title.setVisible(false);
        start.setVisible(false);
        credits.setVisible(false);

        creditstextPanel = new JPanel();
        creditstextPanel.setBounds(75, 100, 600, 250);
        creditstextPanel.setBackground(Color.BLACK);

        creditstextarea1 = new JTextArea("Designed, programmed, and created by Connor Morley");
        creditstextarea1.setBounds(100, 100, 600, 600);
        creditstextarea1.setBackground(Color.BLACK);
        creditstextarea1.setForeground(Color.WHITE);
        creditstextarea1.setFont(credfont);
        creditstextarea1.setLineWrap(true);
        creditstextarea1.setEditable(false);

        creditstextarea2 = new JTextArea("This product is not affiliated with or created by Wizards of the Coast. Inspired  by ItsADndMonsterNow's item and potion generator programs. ");
        creditstextarea2.setBounds(100, 200, 600, 600);
        creditstextarea2.setBackground(Color.BLACK);
        creditstextarea2.setForeground(Color.WHITE);
        creditstextarea2.setFont(credfont2);
        creditstextarea2.setLineWrap(true);
        creditstextarea2.setEditable(false);

        creditstextPanel.add(creditstextarea1);
        creditstextPanel.add(creditstextarea2);

        cont.add(creditstextPanel);
    }

    public class CreditsHandler implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            creditsScreen();
        }
    }
}