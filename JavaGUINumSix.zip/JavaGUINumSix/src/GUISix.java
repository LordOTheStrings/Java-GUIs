import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.*;

public class GUISix extends JPanel implements ActionListener {
    Timer time = new Timer(5, this);
    int x = 0, velocity = 2;

    @Override
    public void actionPerformed(ActionEvent e) {
        x = x + velocity;
        repaint();

        if (x < 0 || x > 200) {
            velocity = -velocity;
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(Color.BLUE);

        g.fillOval(x, x, 50, 50);

        time.start();
    }

    public static void main(String[] args) {
        GUISix six = new GUISix();
        JFrame f = new JFrame();

        f.setTitle("JavaGUISix");
        f.setSize(250, 250);
        f.add(six);
        f.setResizable(false);
        f.setVisible(true);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}