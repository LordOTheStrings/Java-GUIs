import javax.swing.*;
import java.awt.*;


public class GUITwo {

    JPanel imagePanel, titlePanel;
    JLabel imageLabel, titleLabel;
    Container cont;
    ImageIcon image;

    Font tfont = new Font("Times New Roman", Font.BOLD, 44);

    public static void main(String[] args) {

        new GUITwo();
    }

    public GUITwo() {
        JFrame f = new JFrame("GUI Two");
        cont = f.getContentPane();

        imageLabel = new JLabel();
        image = new ImageIcon(".//res//Morley//6thGradeMorley.jpg");

        imagePanel = new JPanel();
        imagePanel.setBounds(115, 100, 500, 250);
        imagePanel.setBackground(Color.BLACK);
        cont.add(imagePanel);

        imageLabel.setIcon(image);
        imagePanel.add(imageLabel);

        titlePanel = new JPanel();
        titlePanel.setBounds(92, 375, 550, 150);
        titlePanel.setBackground(Color.BLACK);
        titleLabel = new JLabel("Through the Lens of Morley");
        titleLabel.setForeground(Color.GREEN);
        titleLabel.setFont(tfont);
        titlePanel.add(titleLabel);
        cont.add(titlePanel);

        f.setSize(750, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.BLACK);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }
}
