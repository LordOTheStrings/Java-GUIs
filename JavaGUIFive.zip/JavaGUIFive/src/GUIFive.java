import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class GUIFive {

    JPanel titlePanel;
    JLabel titleLabel;
    Container cont;
    JTextField scary;

    Font tfont = new Font("Times New Roman", Font.ITALIC, 44);
    JButton spook;

    public static void main(String[] args) {

        new GUIFive();
    }

    public GUIFive() {
        JFrame f = new JFrame("GUI Four");
        cont = f.getContentPane();

        titlePanel = new JPanel();
        titlePanel.setBounds(185, 100, 350, 200);
        titlePanel.setBackground(Color.BLACK);
        titleLabel = new JLabel("SPOOKTOBER");
        titleLabel.setFont(tfont);
        titleLabel.setForeground(Color.ORANGE);
        titlePanel.add(titleLabel);
        cont.add(titlePanel);

        JTextField scary = new JTextField(50);
        scary.setBounds(340, 215, 390, 125);
        scary.setEditable(false);
        f.add(scary);

        JButton spook = new JButton();
        spook.setBounds(10, 200, 275, 150);
        spook.setText("Spooky");
        spook.setBackground(Color.ORANGE);
        cont.add(spook);

        spook.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scary.setText("YOU'VE BEEN SPOOKED FOR 42069 YEARS BY MR.BONES lmaoxd");
            }
        });

        f.setSize(750, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.BLACK);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }
}
