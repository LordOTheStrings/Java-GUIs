import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class GUIFour {

    JPanel titlePanel;
    JLabel titleLabel;
    Container cont;

    Font tfont = new Font("Arial", Font.ITALIC, 44);
    JButton button;

    public static void main(String[] args) {

        new GUIFour();
    }

    public GUIFour() {
        JFrame f = new JFrame("GUI Four");
        cont = f.getContentPane();

        JButton button = new JButton("Random Color Gen");
        button.setBounds(200, 150, 300, 150);
        f.add(button);
        button.addActionListener(e -> {
            titleLabel.setForeground(randomColor());
            titlePanel.setBackground(randomColor());
        });

        titlePanel = new JPanel();
        titlePanel.setBounds(0, 0, 750, 500);
        titlePanel.setBackground(Color.GRAY);
        titleLabel = new JLabel("Color Changer");
        titleLabel.setFont(tfont);
        titlePanel.add(titleLabel);
        cont.add(titlePanel);

        f.setSize(750, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.GRAY);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }

    public Color randomColor() {
        int r = (int)(Math.random() * 256);
        int g = (int)(Math.random() * 256);
        int b = (int)(Math.random() * 256);
        return (new Color (r, g, b));
    }
}
