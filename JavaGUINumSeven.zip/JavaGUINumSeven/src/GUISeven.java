import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class GUISeven {

    JPanel titlePanel;
    JLabel titleLabel;
    Container cont;

    Font tfont = new Font("Arial", Font.ITALIC, 44);

    public static void main(String[] args) {
        new GUISeven();
    }

    public GUISeven() {
        JFrame f = new JFrame("GUI Four");
        cont = f.getContentPane();

        titlePanel = new JPanel();
        titlePanel.setBounds(105, 100, 350, 200);
        titlePanel.setBackground(Color.BLACK);
        titleLabel = new JLabel("¡Ay Caramba!");
        titleLabel.setFont(tfont);
        titleLabel.setForeground(Color.YELLOW);
        titlePanel.add(titleLabel);
        cont.add(titlePanel);

        JButton button = new JButton();
        button.setBounds(100, 200, 375, 500);
        button.setIcon(new ImageIcon("C:\\Users\\cmorl\\IdeaProjects\\JavaGUINumSeven\\src\\res\\bart simpson.png"));
        button.setBackground(Color.YELLOW);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(f, "EAT MY SHORTS!!! >:)");
            }
        });

        cont.add(button);

        f.setSize(600, 800);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.BLACK);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }

}
