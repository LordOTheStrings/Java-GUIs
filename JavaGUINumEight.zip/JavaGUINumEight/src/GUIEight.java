import javax.swing.*;
import java.awt.*;

public class GUIEight {

    JPanel titlePanel;
    JLabel titleLabel;
    JMenuBar menuBar;
    JMenu menu, menu2, menu3;
    JMenuItem file, view, path, edit;
    Container cont;

    Font tfont = new Font("Arial", Font.BOLD, 44);

    public static void main(String[] args) {
        new GUIEight();
    }

    public GUIEight() {
        JFrame f = new JFrame("GUI Four");
        cont = f.getContentPane();

        titlePanel = new JPanel();
        titlePanel.setBounds(88, 250, 400, 200);
        titlePanel.setBackground(Color.BLACK);
        titleLabel = new JLabel("JMENU EXAMPLE");
        titleLabel.setFont(tfont);
        titleLabel.setForeground(Color.CYAN);
        titlePanel.add(titleLabel);
        cont.add(titlePanel);

        menu = new JMenu("File");
        menu2 = new JMenu("View");
        menu3 = new JMenu("Edit");

        menuBar = new JMenuBar();

        file = new JMenuItem("Save as");
        view = new JMenuItem("System Properties");
        path = new JMenuItem("File Path");
        edit = new JMenuItem("File Name");

        menu.add(file);
        menu2.add(view);
        menu2.add(path);
        menu3.add(edit);

        menuBar.add(menu);
        menuBar.add(menu2);
        menuBar.add(menu3);
        f.setJMenuBar(menuBar);

        f.setSize(600, 600);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.BLACK);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }
}
