package com.codebind;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUIOne {
    private JButton playYourBinaryMessageButton;
    private JPanel panelMainOne;

    public GUIOne() {
        playYourBinaryMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "01001000 01100101 01101100 01101100 01101111 00100000 01110111 01101111 01110010 01101100 01100100 00100001");
            }
        });
    }

    public static void main(String[] args) {
        JFrame f = new JFrame("GUIOne");
        f.setContentPane(new GUIOne().panelMainOne);
        f.setResizable(false);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(true);
    }
}