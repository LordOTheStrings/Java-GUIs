import javax.swing.*;
import java.awt.*;

public class GUINine{

    JPanel titlePanel;
    JLabel titleLabel;
    JTable table;
    Container cont;

    public static void main(String[] args) {
        new GUINine();
    }

    public GUINine() {
        JFrame f = new JFrame("GUI Four");
        cont = f.getContentPane();

        titlePanel = new JPanel();
        titlePanel.setBounds(88, 250, 400, 200);
        titlePanel.setBackground(Color.WHITE);
        cont.add(titlePanel);

        String[][] info = {{"Beholder", "Aberration", "Lawful Evil", "13"},
                {"Goblin", "Humanoid", "Neutral Evil", "1/4"},
                {"Flumph", "Aberration", "Lawful good", "1/8"}};
        String[] columns = {"Monster", "Type", "Alignment", "Challenge Rating"};

        JTable table = new JTable(info, columns);
        table.setBounds(65, 200, 650, 250);
        f.add(table);

        f.setSize(800, 600);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.WHITE);
        f.setLayout(null);
        f.setResizable(false);
        f.setVisible(true);
    }
}
